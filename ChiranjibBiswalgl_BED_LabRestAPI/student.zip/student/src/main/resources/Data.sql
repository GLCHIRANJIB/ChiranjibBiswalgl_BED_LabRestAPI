-- Insert data into Student Table
INSERT INTO STUDENT VALUES (1, 'Suresh Reddy','B.Tech','India');
INSERT INTO STUDENT VALUES (2, 'Murali Mohan','B.Arch','Canada');
INSERT INTO STUDENT VALUES (3, 'Daniel Denson','B.Tech','New Zealand');
INSERT INTO STUDENT VALUES (4, 'Tanya Gupta','B.Com','USA');



